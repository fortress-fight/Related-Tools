function sayName (){
    alert('ff')
}
function sayHi(){
    alert(1)
};
console.log(11);